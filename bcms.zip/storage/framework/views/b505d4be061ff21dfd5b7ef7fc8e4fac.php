

<?php $__env->startSection('content'); ?>

    <h1>All Posts</h1>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div>
            <h2><?php echo e($post->title); ?></h2>
            <p><?php echo e(Str::limit($post->content, 100)); ?></p>
            <a href="<?php echo e(route('posts.show', $post->id)); ?>">Read More</a>
        </div>
        <meta name="description" content="<?php echo e(Str::limit($post->content, 100)); ?>">
<meta property="og:description" content="<?php echo e(Str::limit($post->content, 100)); ?>">
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogCMS\resources\views/posts/index.blade.php ENDPATH**/ ?>