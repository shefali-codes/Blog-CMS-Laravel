<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Dashboard</h1>

    <div class="bg-white shadow-md rounded-lg p-6">
        <h2 class="text-xl font-semibold mb-4">Latest Posts</h2>

        <table class="min-w-full bg-white border border-gray-300 rounded-lg overflow-hidden">
            <thead>
                <tr class="bg-gray-200">
                    <th class="py-2 px-4 border">#</th>
                    <th class="py-2 px-4 border">Title</th>
                    <th class="py-2 px-4 border">Author</th>
                    <th class="py-2 px-4 border">Created At</th>
                    <th class="py-2 px-4 border">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="border-b">
                        <td class="py-2 px-4 border"><?php echo e($index + 1); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($post->title); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($post->user->name ?? 'Unknown'); ?></td>
                        <td class="py-2 px-4 border"><?php echo e($post->created_at->format('d M Y')); ?></td>
                        <td class="py-2 px-4 border">
                            <a href="" class="text-blue-500 hover:underline">View</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <div class="mt-4">
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\BlogCMS\resources\views/dashboard.blade.php ENDPATH**/ ?>