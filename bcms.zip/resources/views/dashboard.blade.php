@extends('layouts.app')

@section('content')
<div class="container mx-auto px-4 py-8">
    <h1 class="text-3xl font-bold mb-6">Dashboard</h1>

    <div class="bg-white shadow-md rounded-lg p-6">
        <h2 class="text-xl font-semibold mb-4">Latest Posts</h2>

        <table class="min-w-full bg-white border border-gray-300 rounded-lg overflow-hidden">
            <thead>
                <tr class="bg-gray-200">
                    <th class="py-2 px-4 border">#</th>
                    <th class="py-2 px-4 border">Title</th>
                    <th class="py-2 px-4 border">Author</th>
                    <th class="py-2 px-4 border">Created At</th>
                    <th class="py-2 px-4 border">Actions</th>
                </tr>
            </thead>
            <tbody>
                @foreach($posts as $index => $post)
                    <tr class="border-b">
                        <td class="py-2 px-4 border">{{ $index + 1 }}</td>
                        <td class="py-2 px-4 border">{{ $post->title }}</td>
                        <td class="py-2 px-4 border">{{ $post->user->name ?? 'Unknown' }}</td>
                        <td class="py-2 px-4 border">{{ $post->created_at->format('d M Y') }}</td>
                        <td class="py-2 px-4 border">
                            <a href="" class="text-blue-500 hover:underline">View</a>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

        <div class="mt-4">
            
        </div>
    </div>
</div>
@endsection
