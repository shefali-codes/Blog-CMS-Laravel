@extends('layouts.app')

@section('content')

    <h1>All Posts</h1>
    @foreach($posts as $post)
        <div>
            <h2>{{ $post->title }}</h2>
            <p>{{ Str::limit($post->content, 100) }}</p>
            <a href="{{ route('posts.show', $post->id) }}">Read More</a>
        </div>
        <meta name="description" content="{{ Str::limit($post->content, 100) }}">
<meta property="og:description" content="{{ Str::limit($post->content, 100) }}">
    @endforeach
@endsection

